import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Link, Routes, Navigate } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import ProductForm from './components/ProductForm';
import UserManagement from './components/UserManagement';
import SignUpForm from './components/SignUpForm';
import LoginForm from './components/LoginForm';
import StockManagement from './components/StockManagement'; 
import Logout from './components/Logout'; 
import './App.css';

const App = () => {
  const [products, setProducts] = useState([]);
  const [users, setUsers] = useState([]);
  const [isSignedIn, setIsSignedIn] = useState(false); 
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const storedProducts = JSON.parse(localStorage.getItem('products')) || [];
    setProducts(storedProducts);
  }, []);

  useEffect(() => {
    localStorage.setItem('products', JSON.stringify(products));
  }, [products]);

  const addProduct = (newProduct) => {
    setProducts((prevProducts) => [...prevProducts, newProduct]);
  };

  const handleUserSignIn = (user) => {
    setIsSignedIn(true);
    setCurrentUser(user);
  };

  const handleUserSignOut = () => {
    setIsSignedIn(false);
    setCurrentUser(null);
  };

  return (
    <Router>
      <div className="app-container">
        <h1>Wings Cafe Inventory System</h1>
        <nav>
          {isSignedIn && (
            <>
              <Link to="/dashboard">Dashboard</Link>
              <Link to="/stock-management">Stock Management</Link>
              <Link to="/user-management">User Management</Link>
              <button onClick={handleUserSignOut}>Logout</button>
            </>
          )}
          {!isSignedIn && (
            <>
              <Link to="/login">Login</Link>
              <Link to="/signup">Sign Up</Link>
            </>
          )}
        </nav>

        <Routes>
          <Route
            path="/"
            element={isSignedIn ? <Navigate to="/dashboard" /> : <Navigate to="/login" />}
          />
          <Route path="/login" element={<LoginForm setIsSignedIn={handleUserSignIn} users={users} />} />
          <Route path="/signup" element={<SignUpForm users={users} setUsers={setUsers} setIsSignedIn={handleUserSignIn} />} />
          <Route path="/dashboard" element={isSignedIn ? <Dashboard products={products} addProduct={addProduct} /> : <Navigate to="/login" />} />
          <Route path="/product-form" element={<ProductForm addProduct={addProduct} />} />
          <Route path="/user-management" element={isSignedIn ? <UserManagement users={users} setUsers={setUsers} /> : <Navigate to="/login" />} />
          <Route path="/stock-management" element={isSignedIn ? <StockManagement /> : <Navigate to="/login" />} />
          <Route path="/logout" element={<Logout handleUserSignOut={handleUserSignOut} />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
